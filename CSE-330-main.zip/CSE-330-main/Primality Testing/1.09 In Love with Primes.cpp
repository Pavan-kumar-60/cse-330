#include <iostream>
using namespace std;
int main() {
int n;
int t;
cin>>t;
while(t--)
{
cin>>n;
if(n==2)
{
	cout<<"Arjit"<<endl;
}
else
{
	cout<<"Deepa"<<endl;
}
}
}
